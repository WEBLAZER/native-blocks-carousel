<?php
// Fonctions du thème WEB LAZER

// Empêcher l'accès direct
if (!defined('ABSPATH')) {
	exit;
}

// Configuration du thème
function weblazer_setup()
{
	add_theme_support('post-thumbnails');
	add_theme_support('menus');
	add_theme_support('title-tag');
	add_theme_support('editor-styles');
}
add_action('after_setup_theme', 'weblazer_setup');

// Charger les styles dans l'éditeur Gutenberg
function weblazer_editor_styles()
{
	add_editor_style('style.css');
}
add_action('admin_init', 'weblazer_editor_styles');

// Charger le fichier style.css côté public
function weblazer_enqueue_styles()
{
	wp_enqueue_style('weblazer-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'weblazer_enqueue_styles');

// Force la generation des images en webp
add_filter('webp_uploads_discard_larger_generated_images', '__return_false');

// Charger les modules JavaScript
function weblazer_enqueue_scripts()
{

	// Script principal
	wp_enqueue_script(
		'weblazer-main',
		get_template_directory_uri() . '/script.js',
		array('jquery'),
		'1.0.0',
		true
	);
}
add_action('wp_enqueue_scripts', 'weblazer_enqueue_scripts');
