# Guide d'Optimisation du Workflow - Any Block Carousel Slider

## 🎯 Vue d'Ensemble

Ce guide vous aide à optimiser votre workflow de développement WordPress avec :
- **GitHub** : Développement et versioning
- **WordPress.org SVN** : Publication officielle
- **SSHFS** : Accès aux fichiers distants
- **Chrome DevTools Workspace** : Développement CSS en direct

---

## 📋 Configuration Initiale

### 1. Configuration SVN (Éviter de retaper les identifiants)

```bash
# Créer un fichier de configuration SVN
mkdir -p ~/.subversion/auth/svn.simple

# Stocker les identifiants de manière sécurisée
# SVN demandera les identifiants une fois, puis les stockera dans le keychain
svn checkout https://plugins.svn.wordpress.org/any-block-carousel-slider
# Entrer les identifiants quand demandé (stockés automatiquement)
```

**Alternative :** Créer un fichier `~/.subversion/config` :
```ini
[auth]
password-stores = keychain
store-passwords = yes
```

### 2. Alias Git Utiles

Ajouter dans `~/.zshrc` ou `~/.bashrc` :

```bash
# Alias pour le plugin
alias nbc="cd ~/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider"
alias abcs-svn="cd ~/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider-svn"

# Git shortcuts
alias gst="git status"
alias gco="git checkout"
alias gaa="git add ."
alias gcm="git commit -m"
alias gps="git push"
alias gpl="git pull"

# SVN shortcuts
alias svnst="svn status"
alias svnup="svn update"
alias svndiff="svn diff"
```

Puis recharger : `source ~/.zshrc`

---

## 🔄 Workflow Recommandé

### Workflow Standard (Développement → Publication)

```
1. Développement (GitHub)
   ↓
2. Tests locaux
   ↓
3. Commit + Push GitHub
   ↓
4. Synchronisation SVN (trunk)
   ↓
5. Tag SVN (version)
   ↓
6. Assets WordPress.org (.wordpress-org/)
```

### Structure des Dossiers Recommandée

```
~/Sites/native-blocks-carousel.weblazer.fr/
├── wp-content/plugins/
│   ├── any-block-carousel-slider/          # Git repo (développement)
│   └── any-block-carousel-slider-svn/      # SVN checkout (publication)
│       ├── trunk/                       # Version de développement
│       ├── tags/                        # Versions publiées
│       │   ├── 1.0.0/
│       │   └── 1.0.1/
│       └── assets/                      # Assets WordPress.org
```

---

## 🚀 Scripts d'Automatisation

### Script 1 : Synchronisation Git → SVN (trunk)

Créer `scripts/sync-to-svn.sh` :

```bash
#!/bin/bash

# Script de synchronisation Git → SVN trunk
# Usage: ./scripts/sync-to-svn.sh

set -e

# Couleurs pour les messages
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Chemins
GIT_DIR="$HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider"
SVN_DIR="$HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider-svn"

echo -e "${YELLOW}🔄 Synchronisation Git → SVN trunk...${NC}"

# Vérifier que nous sommes dans le bon répertoire Git
cd "$GIT_DIR"
if [ ! -d ".git" ]; then
    echo "❌ Erreur: Pas un dépôt Git valide"
    exit 1
fi

# Vérifier que le dépôt SVN existe
if [ ! -d "$SVN_DIR/.svn" ]; then
    echo "❌ Erreur: Dépôt SVN non trouvé. Exécutez d'abord: svn checkout"
    exit 1
fi

# Liste des fichiers à synchroniser (exclure les fichiers de dev)
FILES_TO_SYNC=(
    "any-block-carousel-slider.php"
    "readme.txt"
    "LICENSE"
    "includes/"
    "assets/"
    "languages/"
)

# Copier les fichiers
echo -e "${YELLOW}📁 Copie des fichiers...${NC}"
for file in "${FILES_TO_SYNC[@]}"; do
    if [ -e "$GIT_DIR/$file" ]; then
        echo "  → $file"
        rsync -av --delete "$GIT_DIR/$file" "$SVN_DIR/trunk/" --exclude='.git' --exclude='node_modules' --exclude='.DS_Store'
    fi
done

# Exclure les fichiers de développement
echo -e "${YELLOW}🧹 Nettoyage des fichiers de dev...${NC}"
cd "$SVN_DIR/trunk"
rm -f ARCHITECTURE.md COMPLIANCE_REPORT.md PRE_SUBMISSION_CHECKLIST.md SEO_AUDIT_COMPETITOR.md WORKFLOW_OPTIMIZATION.md
rm -rf .git .gitignore

# Vérifier les modifications SVN
cd "$SVN_DIR"
echo -e "${YELLOW}📊 Statut SVN:${NC}"
svn status

# Demander confirmation avant commit
read -p "Voulez-vous commit et push vers SVN? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    read -p "Message de commit: " commit_message
    if [ -z "$commit_message" ]; then
        commit_message="Sync from Git: $(date +%Y-%m-%d)"
    fi
    
    svn add --force trunk/
    svn commit -m "$commit_message"
    echo -e "${GREEN}✅ Synchronisation terminée!${NC}"
else
    echo -e "${YELLOW}⚠️  Modifications préparées mais non commitées${NC}"
fi
```

### Script 2 : Création d'un Tag SVN (Version)

Créer `scripts/create-svn-tag.sh` :

```bash
#!/bin/bash

# Script pour créer un tag SVN depuis trunk
# Usage: ./scripts/create-svn-tag.sh 1.0.2

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

SVN_DIR="$HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider-svn"

# Vérifier la version
if [ -z "$1" ]; then
    echo -e "${RED}❌ Usage: $0 <version>${NC}"
    echo "Exemple: $0 1.0.2"
    exit 1
fi

VERSION=$1
TAG_DIR="$SVN_DIR/tags/$VERSION"

# Vérifier que le tag n'existe pas déjà
if [ -d "$TAG_DIR" ]; then
    echo -e "${RED}❌ Le tag $VERSION existe déjà!${NC}"
    exit 1
fi

cd "$SVN_DIR"

# Mettre à jour trunk
echo -e "${YELLOW}🔄 Mise à jour trunk...${NC}"
svn update trunk

# Créer le tag depuis trunk
echo -e "${YELLOW}🏷️  Création du tag $VERSION...${NC}"
svn copy trunk/ "tags/$VERSION" -m "Tag version $VERSION"

# Commit le tag
echo -e "${YELLOW}📤 Push du tag vers WordPress.org...${NC}"
svn commit -m "Release version $VERSION"

echo -e "${GREEN}✅ Tag $VERSION créé avec succès!${NC}"
echo -e "${GREEN}   URL: https://wordpress.org/plugins/any-block-carousel-slider/developers/${NC}"
```

### Script 3 : Synchronisation des Assets WordPress.org

Créer `scripts/sync-assets.sh` :

```bash
#!/bin/bash

# Script pour synchroniser les assets WordPress.org
# Usage: ./scripts/sync-assets.sh

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

GIT_DIR="$HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider"
SVN_DIR="$HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider-svn"

echo -e "${YELLOW}🖼️  Synchronisation des assets WordPress.org...${NC}"

# Copier les assets depuis .wordpress-org/ vers assets/
if [ -d "$GIT_DIR/.wordpress-org" ]; then
    echo "  → Copie des screenshots, bannières et icônes..."
    rsync -av "$GIT_DIR/.wordpress-org/" "$SVN_DIR/assets/" --exclude='.DS_Store'
    
    cd "$SVN_DIR"
    svn add assets/ 2>/dev/null || true
    svn status assets/
    
    read -p "Voulez-vous commit les assets? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        svn commit -m "Update WordPress.org assets"
        echo -e "${GREEN}✅ Assets synchronisés!${NC}"
    fi
else
    echo -e "${YELLOW}⚠️  Dossier .wordpress-org non trouvé${NC}"
fi
```

### Script 4 : Workflow Complet (Développement → Publication)

Créer `scripts/release.sh` :

```bash
#!/bin/bash

# Script de release complète
# Usage: ./scripts/release.sh 1.0.2 "Description des changements"

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

GIT_DIR="$HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider"

if [ -z "$1" ]; then
    echo -e "${RED}❌ Usage: $0 <version> [message]${NC}"
    echo "Exemple: $0 1.0.2 \"Fix: Correction du scroll-snap pour Post Template\""
    exit 1
fi

VERSION=$1
MESSAGE=${2:-"Release version $VERSION"}

cd "$GIT_DIR"

# 1. Vérifier que tout est commité
if [ -n "$(git status --porcelain)" ]; then
    echo -e "${RED}❌ Des modifications non commitées existent!${NC}"
    git status
    exit 1
fi

# 2. Mettre à jour la version dans le fichier principal
echo -e "${YELLOW}📝 Mise à jour de la version...${NC}"
sed -i '' "s/Version: .*/Version: $VERSION/" any-block-carousel-slider.php
sed -i '' "s/Stable tag: .*/Stable tag: $VERSION/" readme.txt
sed -i '' "s/define('ANY_BLOCK_CAROUSEL_SLIDER_VERSION', .*/define('ANY_BLOCK_CAROUSEL_SLIDER_VERSION', '$VERSION');/" any-block-carousel-slider.php

# 3. Commit et push Git
echo -e "${YELLOW}📤 Push vers GitHub...${NC}"
git add any-block-carousel-slider.php readme.txt
git commit -m "Release version $VERSION"
git tag -a "v$VERSION" -m "$MESSAGE"
git push origin main
git push origin "v$VERSION"

# 4. Synchroniser vers SVN trunk
echo -e "${YELLOW}🔄 Synchronisation vers SVN trunk...${NC}"
"$GIT_DIR/scripts/sync-to-svn.sh"

# 5. Créer le tag SVN
echo -e "${YELLOW}🏷️  Création du tag SVN...${NC}"
"$GIT_DIR/scripts/create-svn-tag.sh" "$VERSION"

# 6. Synchroniser les assets
echo -e "${YELLOW}🖼️  Synchronisation des assets...${NC}"
"$GIT_DIR/scripts/sync-assets.sh"

echo -e "${GREEN}✅ Release $VERSION terminée avec succès!${NC}"
echo -e "${GREEN}   GitHub: https://github.com/WEBLAZER/any-block-carousel-slider/releases/tag/v$VERSION${NC}"
echo -e "${GREEN}   WordPress.org: https://wordpress.org/plugins/any-block-carousel-slider/developers/${NC}"
```

---

## 🔧 Configuration SSHFS Optimisée

### Montage Automatique au Démarrage

Créer `scripts/mount-sshfs.sh` :

```bash
#!/bin/bash

# Script pour monter SSHFS automatiquement
# Usage: ./scripts/mount-sshfs.sh

REMOTE_HOST="votre-serveur.com"
REMOTE_USER="votre-user"
REMOTE_PATH="/var/www/html"
LOCAL_PATH="$HOME/Sites/native-blocks-carousel.weblazer.fr"

# Vérifier si déjà monté
if mountpoint -q "$LOCAL_PATH"; then
    echo "✅ SSHFS déjà monté sur $LOCAL_PATH"
    exit 0
fi

# Créer le répertoire si nécessaire
mkdir -p "$LOCAL_PATH"

# Monter avec options optimisées
sshfs "$REMOTE_USER@$REMOTE_HOST:$REMOTE_PATH" "$LOCAL_PATH" \
    -o reconnect \
    -o ServerAliveInterval=15 \
    -o ServerAliveCountMax=3 \
    -o cache=yes \
    -o compression=no \
    -o follow_symlinks

echo "✅ SSHFS monté sur $LOCAL_PATH"
```

### Démontage

Créer `scripts/unmount-sshfs.sh` :

```bash
#!/bin/bash

LOCAL_PATH="$HOME/Sites/native-blocks-carousel.weblazer.fr"

if mountpoint -q "$LOCAL_PATH"; then
    fusermount -u "$LOCAL_PATH" || umount "$LOCAL_PATH"
    echo "✅ SSHFS démonté"
else
    echo "⚠️  SSHFS n'est pas monté"
fi
```

### Ajouter au LaunchAgent (macOS)

Créer `~/Library/LaunchAgents/com.weblazer.sshfs.plist` :

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.weblazer.sshfs</string>
    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>/Users/arthurballan/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider/scripts/mount-sshfs.sh</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <false/>
</dict>
</plist>
```

Puis charger : `launchctl load ~/Library/LaunchAgents/com.weblazer.sshfs.plist`

---

## 🎨 Chrome DevTools Workspace avec SSHFS

### Configuration Workspace

1. Ouvrir Chrome DevTools (F12)
2. Aller dans **Sources** → **Filesystem**
3. Cliquer sur **+ Add folder to workspace**
4. Sélectionner le dossier monté via SSHFS
5. Autoriser l'accès

### Avantages

- Modifications CSS en direct (sauvegarde automatique)
- Pas besoin de recharger manuellement
- Débogage JavaScript amélioré
- Source maps fonctionnent correctement

### Astuce : Hot Reload

Ajouter dans votre `functions.php` ou plugin :

```php
// Rechargement automatique en développement
if (defined('WP_DEBUG') && WP_DEBUG) {
    add_action('wp_head', function() {
        echo '<script>if (window.location.hostname === "localhost" || window.location.hostname.includes(".local")) { document.write(\'<script src="http://localhost:35729/livereload.js"></script>\'); }</script>';
    });
}
```

---

## 📝 Checklist de Release

Créer un fichier `RELEASE_CHECKLIST.md` :

```markdown
# Checklist de Release

## Avant la Release

- [ ] Tests sur WordPress 6.0 (version minimale)
- [ ] Tests sur WordPress 6.8 (version testée)
- [ ] Tests PHP 7.4 et 8.1+
- [ ] Vérification avec Plugin Check
- [ ] Mise à jour du changelog dans readme.txt
- [ ] Mise à jour de la version dans any-block-carousel-slider.php
- [ ] Vérification des screenshots dans .wordpress-org/
- [ ] Tests des fonctionnalités principales

## Pendant la Release

- [ ] Commit et push GitHub
- [ ] Synchronisation SVN trunk
- [ ] Création du tag SVN
- [ ] Synchronisation des assets
- [ ] Vérification sur WordPress.org

## Après la Release

- [ ] Vérifier que la version apparaît sur WordPress.org
- [ ] Tester l'installation depuis WordPress.org
- [ ] Surveiller les erreurs éventuelles
- [ ] Annoncer la release (si nécessaire)
```

---

## 🚀 Commandes Rapides

### Développement Quotidien

```bash
# Aller au plugin
nbc

# Status Git
gst

# Commit rapide
gaa && gcm "fix: description" && gps

# Synchroniser vers SVN
./scripts/sync-to-svn.sh
```

### Release

```bash
# Release complète
./scripts/release.sh 1.0.2 "Description des changements"
```

### Maintenance

```bash
# Mettre à jour SVN
cd ~/Sites/.../any-block-carousel-slider-svn && svn update

# Vérifier les différences
svn diff trunk/readme.txt

# Voir l'historique
svn log trunk/readme.txt -l 10
```

---

## 💡 Bonnes Pratiques

### 1. Git : Branches de Développement

```bash
# Créer une branche pour une fonctionnalité
git checkout -b feature/nouvelle-fonctionnalite

# Développer, tester, commit
# ...

# Merge dans main
git checkout main
git merge feature/nouvelle-fonctionnalite
git push
```

### 2. SVN : Ne Toucher que trunk/ et tags/

- Ne jamais modifier directement `assets/` (géré par WordPress.org)
- Toujours créer un tag depuis `trunk/`
- Utiliser `svn copy` pour créer des tags (pas de copie manuelle)

### 3. SSHFS : Performance

- Utiliser `cache=yes` pour améliorer les performances
- Éviter les opérations lourdes (grep, find) sur SSHFS
- Préférer travailler localement puis synchroniser

### 4. Sécurité

- Ne jamais commit les identifiants SVN dans Git
- Utiliser `.gitignore` pour exclure les fichiers sensibles
- Stocker les identifiants dans le keychain macOS

---

## 🔍 Dépannage

### SVN : Conflits

```bash
# Voir les conflits
svn status

# Résoudre un conflit
svn resolve --accept theirs-full chemin/fichier

# Ou manuellement
# Éditer le fichier, puis:
svn resolve --accept working chemin/fichier
```

### SSHFS : Déconnexion

```bash
# Vérifier le montage
mountpoint ~/Sites/native-blocks-carousel.weblazer.fr

# Reconnecter
./scripts/mount-sshfs.sh
```

### Git : Annuler un Commit

```bash
# Annuler le dernier commit (garder les modifications)
git reset --soft HEAD~1

# Annuler complètement
git reset --hard HEAD~1
```

---

## 📚 Ressources

- [WordPress Plugin Developer Handbook](https://developer.wordpress.org/plugins/)
- [SVN Quick Reference](https://tortoisesvn.net/docs/release/TortoiseSVN_fr/tsvn-quick-start.html)
- [SSHFS Documentation](https://github.com/libfuse/sshfs/wiki)
- [Chrome DevTools Workspace](https://developer.chrome.com/docs/devtools/workspaces/)

---

**Dernière mise à jour** : 2025-01-24

