# Guide Workflow Quotidien - Any Block Carousel Slider

## 🔒 Sécurité des Identifiants

### ✅ Vérification : Vos identifiants sont SÉCURISÉS

**Bonnes nouvelles :**
- ❌ Aucun identifiant dans les scripts Git
- ❌ Aucun identifiant dans `.gitignore` (pas de risque de commit)
- ✅ Les scripts utilisent le keychain macOS pour SVN
- ✅ Les identifiants SVN ne sont jamais dans le code source

### 🔐 Comment les identifiants sont stockés

1. **SVN** : Utilise le keychain macOS via `~/.subversion/config`
   - Les identifiants sont stockés de manière sécurisée
   - Jamais dans les fichiers du projet
   - Accessible uniquement par votre utilisateur macOS

2. **GitHub** : Utilise SSH ou HTTPS avec credential helper
   - Pas d'identifiants en clair dans le code
   - Utilise les clés SSH ou le keychain

3. **SSHFS** : Utilise les clés SSH
   - Pas de mots de passe en clair
   - Utilise `~/.ssh/id_rsa` ou similaire

### ⚠️ Ce qu'il NE FAUT JAMAIS faire

```bash
# ❌ NE JAMAIS faire ça :
git add scripts/sync-to-svn.sh  # Si le script contient des identifiants
echo "password=xxx" >> config.txt
git commit -m "Add config"  # ❌ Identifiants exposés sur GitHub
```

### ✅ Ce qui est SÉCURISÉ dans votre projet

- ✅ `.gitignore` exclut les fichiers sensibles
- ✅ Les scripts n'ont pas d'identifiants en dur
- ✅ SVN utilise le keychain (pas de mot de passe dans les scripts)
- ✅ Les identifiants WordPress.org ne sont jamais dans Git

---

## 📅 Workflow Quotidien Recommandé

### Scénario 1 : Développement Normal (90% du temps)

**Vous travaillez sur SSHFS → Testez → Publiez**

```
1. Développement sur SSHFS (site de test)
   ↓
2. Test en direct sur le site
   ↓
3. Quand satisfait → Commit Git local
   ↓
4. Push GitHub (quand vous voulez sauvegarder)
   ↓
5. Plus tard → Sync SVN (quand prêt pour WordPress.org)
```

**Commandes quotidiennes :**
```bash
# 1. Aller au plugin
nbc

# 2. Voir ce qui a changé
gst

# 3. Commit local (sans push)
git add .
git commit -m "feat: nouvelle fonctionnalité"

# 4. Push GitHub (quand vous voulez)
gps

# 5. Sync SVN (seulement quand prêt pour WordPress.org)
abcs-sync
```

**Avantages :**
- ✅ Test immédiat sur le site réel
- ✅ Pas de publication automatique (vous contrôlez)
- ✅ Flexibilité totale
- ✅ Pas de risque de publier du code non testé

### Scénario 2 : Correction Urgente

```
1. Correction rapide sur SSHFS
   ↓
2. Test immédiat
   ↓
3. Commit + Push GitHub
   ↓
4. Sync SVN immédiat
   ↓
5. Tag SVN (version patch)
```

**Commandes :**
```bash
# Correction
# ... modifier le fichier ...

# Commit et push
gaa && gcm "fix: correction urgente" && gps

# Sync SVN
abcs-sync

# Tag si nécessaire
abcs-tag 1.0.2
```

### Scénario 3 : Release Majeure

```
1. Finaliser toutes les fonctionnalités
   ↓
2. Tests complets
   ↓
3. Release automatisée (script)
   ↓
   → Met à jour version
   → Push GitHub
   → Sync SVN
   → Crée tag
   → Sync assets
```

**Commande :**
```bash
abcs-release 1.0.2 "Ajout du support Query Loop, amélioration performance"
```

---

## 🤔 Workflow Actuel vs Automatisé

### Votre Workflow Actuel (SSHFS → GitHub → WordPress.org)

**Avantages :**
- ✅ Test immédiat sur environnement réel
- ✅ Vous contrôlez chaque étape
- ✅ Pas de risque de publier du code cassé
- ✅ Flexibilité maximale

**Inconvénients :**
- ⚠️ Plus de manipulations manuelles
- ⚠️ Risque d'oublier une étape
- ⚠️ Plus de temps passé

### Workflow Automatisé (GitHub → WordPress.org automatique)

**Avantages :**
- ✅ Gain de temps
- ✅ Pas d'oublis
- ✅ Cohérence garantie

**Inconvénients :**
- ❌ **Risque majeur** : Publier du code non testé
- ❌ **Risque majeur** : Publier des erreurs en production
- ❌ Perte de contrôle
- ❌ Difficile à déboguer si ça plante
- ❌ WordPress.org peut rejeter si le code n'est pas conforme

### 🎯 Recommandation : Workflow Hybride

**Gardez votre workflow actuel + Automatisez les tâches répétitives**

```
SSHFS (développement) 
  ↓
GitHub (sauvegarde)
  ↓
[MANUEL] Vérification
  ↓
Script automatisé (sync SVN)
```

**Pourquoi ?**

1. **Sécurité** : Vous testez avant de publier
2. **Contrôle** : Vous décidez quand publier
3. **Qualité** : Pas de code cassé sur WordPress.org
4. **Flexibilité** : Vous pouvez skip une étape si nécessaire

---

## 🚫 Pourquoi NE PAS automatiser GitHub → WordPress.org

### Problèmes potentiels

1. **Code non testé publié**
   - Un commit sur GitHub pourrait publier du code cassé
   - WordPress.org pourrait rejeter votre plugin
   - Vos utilisateurs pourraient avoir des erreurs

2. **Conformité WordPress.org**
   - WordPress.org a des règles strictes
   - Un code non conforme = rejet
   - Vous devez vérifier avant de publier

3. **Versions**
   - Vous ne voulez pas publier chaque commit comme version
   - Les versions doivent être planifiées
   - Les changelogs doivent être à jour

4. **Tests**
   - Vous devez tester sur différentes versions WordPress
   - Vous devez vérifier avec Plugin Check
   - Vous devez tester PHP 7.4, 8.1, 8.2

### ✅ Ce qu'on peut automatiser (sans risque)

- ✅ Synchronisation des fichiers (une fois que vous avez vérifié)
- ✅ Création de tags (une fois que vous avez testé)
- ✅ Mise à jour de version (dans le script de release)
- ✅ Synchronisation des assets

### ❌ Ce qu'on ne doit PAS automatiser

- ❌ Publication automatique à chaque commit GitHub
- ❌ Création de tag à chaque push
- ❌ Sync SVN sans vérification
- ❌ Publication sans tests

---

## 📋 Workflow Quotidien Détaillé

### Jour 1-5 : Développement

```bash
# Matin : Aller au plugin
nbc

# Développement sur SSHFS
# ... modifications ...

# Test en direct sur le site
# Ouvrir le site, tester

# Si OK → Commit local
git add .
git commit -m "feat: ajout fonctionnalité X"

# Push GitHub (sauvegarde)
gps

# Pas de sync SVN (pas encore prêt)
```

### Jour 6 : Tests et Préparation

```bash
# Tests complets
# - WordPress 6.0
# - WordPress 6.8
# - PHP 7.4, 8.1
# - Plugin Check

# Si tout OK → Préparer la release
```

### Jour 7 : Release

```bash
# Release automatisée
abcs-release 1.0.2 "Description des changements"

# Vérifier sur WordPress.org
# Ouvrir : https://wordpress.org/plugins/any-block-carousel-slider/developers/
```

---

## 🔄 Workflow Recommandé : Étape par Étape

### Phase 1 : Développement (SSHFS)

```bash
# 1. Travailler sur SSHFS
# Modifier les fichiers directement sur le serveur

# 2. Tester en direct
# Ouvrir le site, vérifier que ça fonctionne

# 3. Commit local (sans push)
git add .
git commit -m "feat: description"
# Pas de push encore, on continue à développer
```

**Pourquoi commit local ?**
- Sauvegarde de votre travail
- Historique clair
- Possibilité de revenir en arrière
- Pas de risque (pas encore sur GitHub)

### Phase 2 : Sauvegarde (GitHub)

```bash
# Quand vous avez fini une fonctionnalité complète
gps  # Push vers GitHub

# Vérifier sur GitHub
# Ouvrir : https://github.com/WEBLAZER/any-block-carousel-slider
```

**Pourquoi push GitHub ?**
- Sauvegarde distante
- Partage avec d'autres développeurs (si besoin)
- Historique accessible partout
- Pas encore publié sur WordPress.org

### Phase 3 : Vérification (Manuel)

```bash
# Avant de publier sur WordPress.org :

# 1. Vérifier avec Plugin Check
# Installer Plugin Check
# Tester le plugin

# 2. Vérifier les versions WordPress
# Tester sur 6.0 et 6.8

# 3. Vérifier le readme.txt
# S'assurer qu'il est à jour

# 4. Vérifier les screenshots
# S'assurer qu'ils sont à jour
```

### Phase 4 : Publication (Script automatisé)

```bash
# Une fois que tout est vérifié :

# Option 1 : Sync simple (trunk seulement)
abcs-sync

# Option 2 : Release complète (version + tag)
abcs-release 1.0.2 "Description"
```

---

## 🎯 Recommandation Finale

### ✅ Workflow Recommandé

```
SSHFS (développement + test)
  ↓
Git (commit local)
  ↓
GitHub (push quand fonctionnalité complète)
  ↓
[PAUSE] Vérification manuelle
  ↓
Script automatisé (sync SVN)
  ↓
WordPress.org (publication)
```

### Pourquoi ce workflow ?

1. **Sécurité** : Test avant publication
2. **Contrôle** : Vous décidez quand publier
3. **Qualité** : Code testé et vérifié
4. **Efficacité** : Scripts automatisent les tâches répétitives
5. **Flexibilité** : Vous pouvez skip une étape si besoin

### Ce qu'on automatise

- ✅ Synchronisation des fichiers (après vérification)
- ✅ Création de tags (après tests)
- ✅ Mise à jour de version (dans release)
- ✅ Synchronisation des assets

### Ce qu'on garde manuel

- ✅ Tests sur le site réel
- ✅ Vérification avec Plugin Check
- ✅ Décision de quand publier
- ✅ Vérification du readme.txt

---

## 🔐 Checklist Sécurité

Avant chaque commit Git, vérifier :

- [ ] Aucun identifiant dans le code
- [ ] Aucun mot de passe en clair
- [ ] `.gitignore` à jour
- [ ] Pas de fichiers sensibles dans le staging

Avant chaque push GitHub :

- [ ] `git status` ne montre rien de sensible
- [ ] `git diff` ne montre pas d'identifiants
- [ ] Les scripts n'ont pas d'identifiants en dur

Avant chaque sync SVN :

- [ ] Code testé et fonctionnel
- [ ] Plugin Check passé
- [ ] readme.txt à jour
- [ ] Version correcte dans les fichiers

---

## 💡 Astuces Quotidiennes

### Commit fréquents, Push moins fréquents

```bash
# Développement : commits fréquents (local)
git commit -m "WIP: en cours de développement"

# Push : seulement quand fonctionnalité complète
git push
```

### Branches pour les fonctionnalités

```bash
# Créer une branche
git checkout -b feature/nouvelle-fonctionnalite

# Développer
# ...

# Merge dans main quand prêt
git checkout main
git merge feature/nouvelle-fonctionnalite
git push
```

### Tags Git pour les versions

```bash
# Créer un tag Git (séparé du tag SVN)
git tag -a v1.0.2 -m "Release 1.0.2"
git push origin v1.0.2
```

---

## 📊 Résumé : Quand Utiliser Quoi

| Action | Quand | Commande |
|--------|-------|----------|
| **Commit local** | Après chaque modification testée | `git commit -m "..."` |
| **Push GitHub** | Quand fonctionnalité complète | `gps` |
| **Sync SVN** | Quand prêt pour WordPress.org | `abcs-sync` |
| **Release** | Version finale testée | `abcs-release 1.0.2 "..."` |

---

**Conclusion :** Gardez votre workflow actuel (SSHFS → GitHub → WordPress.org) mais utilisez les scripts pour automatiser les tâches répétitives. Ne pas automatiser la publication complète, gardez le contrôle manuel pour la qualité et la sécurité.

