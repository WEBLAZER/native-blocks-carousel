# Stratégie d'Animation de l'Icône - WordPress.org

## 📋 Formats Supportés par WordPress.org

WordPress.org accepte plusieurs formats pour les icônes de plugins :

1. **`icon.svg`** (prioritaire) - Format vectoriel, peut être animé
2. **`icon-256x256.png`** (fallback statique) - Format raster, déjà présent
3. **`icon-256x256.gif`** (fallback animé) - Format raster animé, optionnel mais recommandé

## 🎯 Stratégie Recommandée

### Option 1 : SVG Animé + GIF Animé (Recommandé)

**Avantages :**
- ✅ SVG animé : Léger (~4KB), scalable, moderne
- ✅ GIF animé : Compatibilité maximale (tous navigateurs/clients email)
- ✅ WordPress.org utilisera automatiquement le meilleur format supporté

**Fichiers nécessaires :**
- `icon.svg` (animé) - Déjà créé ✅
- `icon-256x256.gif` (animé) - À créer
- `icon-256x256.png` (statique) - Déjà présent ✅

### Option 2 : SVG Animé Seulement

**Avantages :**
- ✅ Plus simple (un seul fichier animé)
- ✅ Léger et moderne

**Inconvénients :**
- ⚠️ Peut ne pas fonctionner dans tous les contextes (emails, anciens navigateurs)
- ⚠️ Certains clients email ne supportent pas les SVG animés

## 🔧 Comment Créer le GIF Animé

### Méthode 1 : Outils en Ligne (Recommandé pour débuter)

1. **SVGator** (https://www.svgator.com/svg-to-gif)
   - Importez `icon.svg`
   - Exportez en GIF animé 256x256px
   - Durée : 4 secondes, boucle infinie

2. **CloudConvert** (https://cloudconvert.com/svg-to-gif)
   - Upload `icon.svg`
   - Paramètres : 256x256px, qualité optimale
   - Téléchargez le GIF

3. **Fotor** (https://www.fotor.com/convert/svg-converter/svg-to-gif)
   - Conversion simple et rapide

### Méthode 2 : Logiciels Desktop

1. **GIMP** (gratuit)
   - Ouvrir `icon.svg` dans GIMP
   - Exporter comme GIF animé
   - Paramètres : 256x256px, boucle infinie

2. **Photoshop**
   - Ouvrir `icon.svg`
   - Créer une timeline d'animation
   - Exporter comme GIF animé

### Méthode 3 : Command Line (si ImageMagick installé)

```bash
# Convertir SVG en frames PNG
convert -background none icon.svg -resize 256x256 frame-%02d.png

# Créer GIF animé depuis les frames
convert -delay 10 -loop 0 frame-*.png icon-256x256.gif

# Nettoyer
rm frame-*.png
```

## 📦 Structure des Fichiers

```
.wordpress-org/
├── icon.svg              # SVG animé (prioritaire)
├── icon-256x256.png      # PNG statique (fallback)
└── icon-256x256.gif      # GIF animé (fallback animé) - À créer
```

## 🎨 Paramètres Recommandés pour le GIF

- **Dimensions** : 256x256px (exactement)
- **Durée** : 4 secondes (même que le SVG)
- **Boucle** : Infinie
- **Qualité** : Optimale (peut être plus lourd, ~50-100KB)
- **Palette** : 256 couleurs (suffisant pour cette icône)

## ✅ Test de Compatibilité

### Vérifier le SVG Animé

1. Ouvrir `icon.svg` dans un navigateur moderne (Chrome, Firefox, Safari)
2. L'animation doit se lancer automatiquement
3. Vérifier que la boucle est fluide

### Vérifier le GIF Animé

1. Ouvrir `icon-256x256.gif` dans un navigateur
2. L'animation doit être identique au SVG
3. Tester dans différents navigateurs

## 🚀 Déploiement sur WordPress.org

1. **Via SVN** : Uploader les fichiers dans `.wordpress-org/`
2. **WordPress.org utilisera automatiquement** :
   - `icon.svg` si supporté (navigateurs modernes)
   - `icon-256x256.gif` si SVG non supporté (emails, anciens navigateurs)
   - `icon-256x256.png` en dernier recours (statique)

## 📝 Notes Importantes

- **WordPress.org ne garantit pas** que les SVG animés fonctionnent partout
- **Le GIF animé est un fallback essentiel** pour la compatibilité maximale
- **Les deux formats peuvent coexister** sans problème
- **WordPress.org choisira automatiquement** le meilleur format supporté

## 🎯 Recommandation Finale

**Créer le GIF animé** pour garantir une compatibilité maximale, tout en conservant le SVG animé pour les environnements modernes qui le supportent.

---

**Prochaine étape** : Créer `icon-256x256.gif` en utilisant l'une des méthodes ci-dessus.

