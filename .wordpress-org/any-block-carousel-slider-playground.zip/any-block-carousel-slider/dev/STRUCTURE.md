# Structure du Projet - Any Block Carousel Slider

## 📁 Vue d'Ensemble

```
any-block-carousel-slider/
│
├── ✅ PUBLIÉ (GitHub + WordPress.org)
│   ├── any-block-carousel-slider.php   # Plugin principal
│   ├── readme.txt                   # Description WordPress.org
│   ├── LICENSE                      # Licence GPL
│   ├── includes/                    # Code PHP
│   ├── assets/                      # CSS et JS
│   └── languages/                   # Traductions
│
└── ❌ NON PUBLIÉ (dev/)
    ├── README.md                     # Guide du dossier dev/
    ├── STRUCTURE.md                  # Ce fichier
    ├── ARCHITECTURE.md              # Documentation technique
    ├── docs/                         # Documentation interne
    │   ├── COMPLIANCE_REPORT.md
    │   ├── PRE_SUBMISSION_CHECKLIST.md
    │   ├── SEO_AUDIT_COMPETITOR.md
    │   ├── WORKFLOW_OPTIMIZATION.md
    │   └── WORKFLOW_QUOTIDIEN.md
    └── scripts/                      # Scripts d'automatisation
        ├── sync-to-svn.sh
        ├── create-svn-tag.sh
        ├── sync-assets.sh
        ├── release.sh
        └── setup-aliases.sh
```

## ✅ Fichiers Publiés

Ces fichiers seront **identiques** sur GitHub et WordPress.org :

| Fichier/Dossier | Description | GitHub | WordPress.org |
|----------------|-------------|--------|---------------|
| `any-block-carousel-slider.php` | Plugin principal | ✅ | ✅ |
| `readme.txt` | Description (requis WP.org) | ✅ | ✅ |
| `LICENSE` | Licence GPL | ✅ | ✅ |
| `includes/` | Code PHP | ✅ | ✅ |
| `assets/` | CSS et JS | ✅ | ✅ |
| `languages/` | Traductions | ✅ | ✅ |

## ❌ Fichiers NON Publiés

Tout ce qui est dans `dev/` est **complètement ignoré** :

| Fichier/Dossier | Description | GitHub | WordPress.org |
|----------------|-------------|--------|---------------|
| `dev/` | **Tout le dossier** | ❌ | ❌ |
| `dev/docs/` | Documentation interne | ❌ | ❌ |
| `dev/scripts/` | Scripts d'automatisation | ❌ | ❌ |
| `dev/ARCHITECTURE.md` | Documentation technique | ❌ | ❌ |

## 🔒 Sécurité

### Vérification Git

```bash
# Vérifier que dev/ est ignoré
git check-ignore dev/
# Devrait afficher : dev/ ✅

# Vérifier le statut
git status
# dev/ ne devrait jamais apparaître ✅
```

### Vérification SVN

Le script `sync-to-svn.sh` supprime automatiquement `dev/` avant de synchroniser.

## 🎯 Avantages de cette Structure

1. **Clarté visuelle** : Vous voyez immédiatement ce qui sera publié
2. **Sécurité** : Impossible de publier accidentellement des fichiers sensibles
3. **Simplicité** : Un seul dossier à ignorer (`dev/`)
4. **Cohérence** : GitHub et WordPress.org ont exactement les mêmes fichiers
5. **Organisation** : Tout le développement au même endroit

## 📝 Utilisation

### Ajouter un fichier de développement

```bash
# Créer dans dev/
touch dev/nouveau-fichier.md

# Automatiquement ignoré ✅
```

### Utiliser les scripts

```bash
# Les scripts sont dans dev/scripts/
./dev/scripts/sync-to-svn.sh
./dev/scripts/release.sh 1.0.2
```

### Voir ce qui sera publié

```bash
# Fichiers trackés par Git (seront publiés)
git ls-files

# Fichiers à la racine (seront publiés)
ls -1 | grep -v "^\.\|^dev$"
```

## 🚀 Workflow

1. **Développement** : Travailler normalement
2. **Fichiers de dev** : Mettre dans `dev/` si nécessaire
3. **Commit** : Seuls les fichiers à la racine sont trackés
4. **Sync SVN** : Le script exclut automatiquement `dev/`
5. **Résultat** : GitHub et WordPress.org ont exactement les mêmes fichiers ✅

## ⚠️ Règles d'Or

1. **Tout ce qui est dans `dev/` reste local**
2. **Tout ce qui est à la racine sera publié**
3. **Ne jamais modifier `.gitignore` pour inclure `dev/`**
4. **Utiliser les scripts pour synchroniser (excluent automatiquement `dev/`)**

