#!/bin/bash

# Script pour synchroniser les assets WordPress.org
# Usage: ./scripts/sync-assets.sh

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

GIT_DIR="$HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider"
SVN_DIR="$HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider-svn"

echo -e "${YELLOW}🖼️  Synchronisation des assets WordPress.org...${NC}"

# Copier les assets depuis .wordpress-org/ vers assets/
if [ -d "$GIT_DIR/.wordpress-org" ]; then
    echo "  → Copie des screenshots, bannières et icônes..."
    rsync -av "$GIT_DIR/.wordpress-org/" "$SVN_DIR/assets/" --exclude='.DS_Store'
    
    cd "$SVN_DIR"
    svn add assets/ 2>/dev/null || true
    svn status assets/
    
    read -p "Voulez-vous commit les assets? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        svn commit -m "Update WordPress.org assets"
        echo -e "${GREEN}✅ Assets synchronisés!${NC}"
    fi
else
    echo -e "${YELLOW}⚠️  Dossier .wordpress-org non trouvé${NC}"
fi

