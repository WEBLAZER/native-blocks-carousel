#!/bin/bash

# Script de release complète
# Usage: ./scripts/release.sh 1.0.2 "Description des changements"

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

GIT_DIR="$HOME/Sites/native-blocks-carousel.weblazer.fr/wp-content/plugins/any-block-carousel-slider"

if [ -z "$1" ]; then
    echo -e "${RED}❌ Usage: $0 <version> [message]${NC}"
    echo "Exemple: $0 1.0.2 \"Fix: Correction du scroll-snap pour Post Template\""
    exit 1
fi

VERSION=$1
MESSAGE=${2:-"Release version $VERSION"}

cd "$GIT_DIR"

# 1. Vérifier que tout est commité
if [ -n "$(git status --porcelain)" ]; then
    echo -e "${RED}❌ Des modifications non commitées existent!${NC}"
    git status
    read -p "Voulez-vous continuer quand même? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# 2. Mettre à jour la version dans le fichier principal
echo -e "${YELLOW}📝 Mise à jour de la version...${NC}"
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS
    sed -i '' "s/Version: .*/Version: $VERSION/" any-block-carousel-slider.php
    sed -i '' "s/Stable tag: .*/Stable tag: $VERSION/" readme.txt
    sed -i '' "s/define('ANY_BLOCK_CAROUSEL_SLIDER_VERSION', .*/define('ANY_BLOCK_CAROUSEL_SLIDER_VERSION', '$VERSION');/" any-block-carousel-slider.php
else
    # Linux
    sed -i "s/Version: .*/Version: $VERSION/" any-block-carousel-slider.php
    sed -i "s/Stable tag: .*/Stable tag: $VERSION/" readme.txt
    sed -i "s/define('ANY_BLOCK_CAROUSEL_SLIDER_VERSION', .*/define('ANY_BLOCK_CAROUSEL_SLIDER_VERSION', '$VERSION');/" any-block-carousel-slider.php
fi

# 3. Commit et push Git
echo -e "${YELLOW}📤 Push vers GitHub...${NC}"
git add any-block-carousel-slider.php readme.txt
git commit -m "Release version $VERSION" || echo "Aucun changement à commit"
git tag -a "v$VERSION" -m "$MESSAGE" || echo "Tag existe déjà"
git push origin main
git push origin "v$VERSION" 2>/dev/null || git push origin --tags

# 4. Synchroniser vers SVN trunk
echo -e "${YELLOW}🔄 Synchronisation vers SVN trunk...${NC}"
"$GIT_DIR/dev/scripts/sync-to-svn.sh"

# 5. Créer le tag SVN
echo -e "${YELLOW}🏷️  Création du tag SVN...${NC}"
"$GIT_DIR/dev/scripts/create-svn-tag.sh" "$VERSION"

# 6. Synchroniser les assets
echo -e "${YELLOW}🖼️  Synchronisation des assets...${NC}"
"$GIT_DIR/dev/scripts/sync-assets.sh"

echo -e "${GREEN}✅ Release $VERSION terminée avec succès!${NC}"
echo -e "${GREEN}   GitHub: https://github.com/WEBLAZER/any-block-carousel-slider/releases/tag/v$VERSION${NC}"
echo -e "${GREEN}   WordPress.org: https://wordpress.org/plugins/any-block-carousel-slider/developers/${NC}"

