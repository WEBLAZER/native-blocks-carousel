#!/bin/bash

# Script pour convertir icon.svg en icon-256x256.png avec Inkscape
# Usage: ./create-png-from-svg.sh

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLUGIN_DIR="$(dirname "$(dirname "$SCRIPT_DIR")")"
SVG_FILE="$PLUGIN_DIR/.wordpress-org/icon.svg"
OUTPUT_PNG="$PLUGIN_DIR/.wordpress-org/icon-256x256.png"

echo "🎨 Conversion de icon.svg en PNG avec Inkscape..."

# Vérifier que Inkscape est installé
if ! command -v inkscape &> /dev/null; then
    echo "❌ Inkscape n'est pas installé"
    echo ""
    echo "📦 Installation (macOS) :"
    echo "   brew install --cask inkscape"
    exit 1
fi

# Vérifier que le fichier SVG existe
if [ ! -f "$SVG_FILE" ]; then
    echo "❌ Fichier SVG introuvable : $SVG_FILE"
    exit 1
fi

echo "📄 Fichier SVG : $SVG_FILE"
echo "📸 Fichier PNG de sortie : $OUTPUT_PNG"
echo ""

# Exporter le SVG en PNG 256x256px
# --export-filename : nom du fichier de sortie
# --export-width et --export-height : dimensions en pixels
# --export-background : couleur de fond (blanc par défaut, ou transparent)
# --export-type : type d'export (png)

echo "🔄 Export en cours..."
inkscape \
    --export-filename="$OUTPUT_PNG" \
    --export-width=256 \
    --export-height=256 \
    --export-type=png \
    "$SVG_FILE" 2>/dev/null

if [ $? -eq 0 ] && [ -f "$OUTPUT_PNG" ]; then
    SIZE=$(ls -lh "$OUTPUT_PNG" | awk '{print $5}')
    echo "✅ PNG créé avec succès : $OUTPUT_PNG"
    echo "📊 Taille : $SIZE"
else
    echo "❌ Erreur lors de l'export"
    echo ""
    echo "💡 Essayez avec la syntaxe alternative :"
    echo "   inkscape --export-png=\"$OUTPUT_PNG\" --export-width=256 --export-height=256 \"$SVG_FILE\""
    exit 1
fi

